USE [Test]
GO
/****** Object:  Table [dbo].[Location]    Script Date: 06-05-2023 11:35:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Location](
	[Id] [int] NULL,
	[Name] [nvarchar](50) NULL,
	[ParentId] [int] NULL,
	[Type] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[User]    Script Date: 06-05-2023 11:35:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Email] [nvarchar](100) NULL,
	[Phone] [nvarchar](15) NULL,
	[Address] [nvarchar](250) NULL,
	[CityId] [int] NULL,
	[StateId] [int] NULL,
	[IsAgree] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[SP_Location]    Script Date: 06-05-2023 11:35:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_Location]
(
	@Parent int = 1
)
AS
BEGIN
	select * from Location where ParentId = @Parent
END
GO
/****** Object:  StoredProcedure [dbo].[SP_User]    Script Date: 06-05-2023 11:35:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_User]
(
	@Mode nvarchar(15),
	@Id int = 0,
	@Name nvarchar(50) = NULL,
	@Email nvarchar(50) = NULL,
	@Phone nvarchar(50) = NULL,
	@Address nvarchar(250) = NULL,
	@StateId int = 0,
	@CityId int = 0,
	@IsAgree bit = 0
)
AS
BEGIN
	if(@Mode = 'Select')
	Begin 
	  If(@Id > 0)
	  begin
	  	  select * from [dbo].[User] where id = @Id
	  end
	  else
	  begin
	  	  select * from dbo.[User]
	  end
	end
	else
	if(@Mode = 'Delete')
	Begin
	  	  delete from dbo.[User] where id = @Id
	end
	else
	if(@Mode = 'InsertOrUpdate')
	Begin
		  If(@Id > 0)
		  begin
	  		  UPDATE [dbo].[User]
			   SET [Name] = @Name
				  ,[Email] = @Email
				  ,[Phone] = @Phone
				  ,[Address] = @Address
				  ,[CityId] = @CityId
				  ,[StateId] = @StateId
				  ,[IsAgree] = @IsAgree
			 WHERE Id= @Id
			 select @Id as Id
		  end
		  else
		  begin
	  		  INSERT INTO [dbo].[User]
				   ([Name]
				   ,[Email]
				   ,[Phone]
				   ,[Address]
				   ,[CityId]
				   ,[StateId]
				   ,[IsAgree])
			 VALUES
				   (@Name
				   ,@Email
				   ,@Phone
				   ,@Address
				   ,@CityId
				   ,@StateId
				   ,@IsAgree)

			select SCOPE_IDENTITY() as Id

		  end
	end
END
GO
