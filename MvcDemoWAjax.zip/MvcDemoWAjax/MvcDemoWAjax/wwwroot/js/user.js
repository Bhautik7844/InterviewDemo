﻿
var userTable, userValidator;
var form = document.getElementById('userForm');

$(function () {
    $("#btnSubmit").prop("disabled", true);
    //validation();
    loadDatatable();
    GetLocation(1, "#state");
    $(document).on('change', '#isAgree', function () {
        if ($(this).is(":checked")) {
            $("#btnSubmit").prop("disabled", false);
        }
        else {
            $("#btnSubmit").prop("disabled", true);
        }
    });

    $(document).on('change', '#state', function () {
        if ($(this).val()) {
            GetLocation(parseInt($(this).val()), "#city");
        }
        else {
            $("#city").html("");
        }
    });

    $(document).on('click', '.btnEdit', function () {

        let id = $(this).attr("data-id");
        $("#id").val(id);
        $("#modalTitle").html("Edit User");
        $.ajax({
            type: 'GET',
            url: "/User/GetUsers?id=" + id,
            success: function (result) {
                GetLocation(result[0].stateId, "#city");
                $("#name").val(result[0].name);
                $("#email").val(result[0].email);
                $("#phone").val(result[0].phone);
                $("#address").val(result[0].address);
                $("#state").val(result[0].stateId);
                setTimeout(function () {
                    $("#city").val(result[0].cityId);
                }, 1000)
                if (result[0].isAgree) {
                    $("#isAgree").prop("checked", true);
                    $("#btnSubmit").prop("disabled", false);
                }
                else {
                    $("#btnSubmit").prop("disabled", true);
                }
                $('#userModal').modal('show');

            }
        });
    });

    $(document).on('click', '.btnDelete', function () {
        let id = $(this).attr("data-id");
        $("#id").val(id);

        if (confirm("Are you sure you wnat to delete this user?")) {
            $.ajax({
                type: 'GET',
                url: "/User/Delete?id=" + id,
                success: function (result) {
                    toastr.success("User Deleted Successfully")
                    userTable.ajax.reload();

                }
            });
        }
    });

    $('#userModal').on('hidden.bs.modal', function (e) {
        $("#id").val(null);
        $("#userForm").trigger("reset");
        $("#modalTitle").html("Add User");
        $("#city").html("");
        $("#btnSubmit").prop("disabled", true);
     
    })

    $(document).on('click', '#btnSubmit', function () {
        var post_data = {
            id: $("#id").val(),
            name: $("#name").val(),
            email: $("#email").val(),
            phone: $("#phone").val(),
            address: $("#address").val(),
            stateId: $("#state").val(),
            cityId: $("#city").val(),
            isAgree: $("#isAgree").is(":checked")
        }
        $.ajax({
            type: 'POST',
            url: "/User/CreateOrEdit",
            data: post_data,
            success: function (result) {
                if (post_data.id) {
                    toastr.success("User Updated Successfully")
                }
                else {
                    toastr.success("User Saved Successfully")
                }
                $('#userModal').modal('hide');
                userTable.ajax.reload();

            }
        });
        //if ($("#userForm").validate()) {
        //    debugger
        //}
    });
    
});

function GetLocation(id, ele) {
    $.ajax({
        type: 'GET',
        url: "/User/GetLocations?parent=" + id,
        success: function (result) {
            $(ele).html('');
            $(ele).append(
                $('<option></option>').val(null).html("---Please select---")
            );

            $.each(result, function (index, item) {
                $(ele).append(
                    $('<option></option>').val(item.value).html(item.text)
                );
            });
        }
    });
}

function validation() {
	userValidator = $("#userForm").validate({
		rules: {
			name: "required",
			email: {
				required: true,
				email: true
			},
			phone: {
				required: true,
				phone: true
			},
            state: "required",
            city: "required",
			isAgree: "required"
		},
		messages: {
			firstname: "Please enter your name",
            email: "Please enter a valid email address",
            phone: "Please enter a valid phone",
            isAgree: "Please accept our policy",
            state: "Please select state",
            city: "Please select city",
		}
    });

}

function loadDatatable() {
    userTable = new DataTable('#userTable', {
        responsive: true,
        ajax: {
            url: "/User/GetUsers",
            dataSrc: ''
        },
        columns: [
            {
                data: 'name',
                
            },
            {
                data: 'email'
            },
            {
                data: 'phone'
            },
            {
                data: 'Action',
                mRender: function (data, type, row) {
                    var html = '<button type="button" class="btn btn-outline-dark btnEdit mr-2" data-id=' + row.id + ' >Edit <i class="fa-solid fa-pencil"></i></button>'
                    html += '<button type="button" class="btn btn-outline-dark btnDelete" data-id=' + row.id + ' >Delete <i class="fa-solid fa-trash"></i></button>'
                    
                    return html;

                }
            }]
    });
}