﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using MvcDemoWAjax.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace MvcDemoWAjax.Services
{
    public class UserService
    {
        string connString = "";
        public UserService(IConfiguration iConfig)
        {
            connString = iConfig.GetValue<string>("ConnectionString:mycon");
        }


        public List<User> GetUsers(int id)
        {
            SqlConnection con = null;
            DataSet ds = null;
            List<User> users = null;
            try
            {
                con = new SqlConnection(connString);
                SqlCommand cmd = new SqlCommand("SP_User", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Mode", "Select");
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Name", null);
                cmd.Parameters.AddWithValue("@Email", null);
                cmd.Parameters.AddWithValue("@Phone", null);
                cmd.Parameters.AddWithValue("@Address", null);
                cmd.Parameters.AddWithValue("@StateId", 0);
                cmd.Parameters.AddWithValue("@CityId", 0);
                cmd.Parameters.AddWithValue("@IsAgree", 0);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                users = new List<User>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    User user = new User();
                    user.Id = Convert.ToInt32(ds.Tables[0].Rows[i]["Id"].ToString());
                    user.Name = ds.Tables[0].Rows[i]["Name"].ToString();
                    user.Address = ds.Tables[0].Rows[i]["Address"].ToString();
                    user.Email = ds.Tables[0].Rows[i]["Email"].ToString();
                    user.Phone = ds.Tables[0].Rows[i]["Phone"].ToString();
                    user.StateId = Convert.ToInt32(ds.Tables[0].Rows[i]["StateId"].ToString());
                    user.CityId = Convert.ToInt32(ds.Tables[0].Rows[i]["CityId"].ToString());
                    user.IsAgree = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsAgree"].ToString());

                    users.Add(user);
                }
                return users;
            }
            catch(Exception ex)
            {
                return users;
            }
            finally
            {
                con.Close();
            }
        }

        public string InsertOrUpdateUser(User user)
        {
            SqlConnection con = null;

            string result = "";
            try
            {
                con = new SqlConnection(connString);
                SqlCommand cmd = new SqlCommand("SP_User", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Mode", "InsertOrUpdate");
                cmd.Parameters.AddWithValue("@Id", user.Id);
                cmd.Parameters.AddWithValue("@Name", user.Name);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                cmd.Parameters.AddWithValue("@Phone", user.Phone);
                cmd.Parameters.AddWithValue("@Address", user.Address);
                cmd.Parameters.AddWithValue("@StateId", user.StateId);
                cmd.Parameters.AddWithValue("@CityId", user.CityId);
                cmd.Parameters.AddWithValue("@IsAgree", user.IsAgree);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch (Exception ex)
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }

        public int DeleteUser(int id)
        {
            SqlConnection con = null;
            int result;
            try
            {
                con = new SqlConnection(connString);
                SqlCommand cmd = new SqlCommand("SP_User", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Mode", "Delete");
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Name", null);
                cmd.Parameters.AddWithValue("@Email", null);
                cmd.Parameters.AddWithValue("@Phone", null);
                cmd.Parameters.AddWithValue("@Address", null);
                cmd.Parameters.AddWithValue("@StateId", 0);
                cmd.Parameters.AddWithValue("@CityId", 0);
                cmd.Parameters.AddWithValue("@IsAgree", 0);
                con.Open();
                result = cmd.ExecuteNonQuery();
                return result;
            }
            catch (Exception ex)
            {
                return result = 0;
            }
            finally
            {
                con.Close();
            }
        }

        public List<SelectListItem> GetLocations(int parent)
        {
            SqlConnection con = null;
            DataSet ds = null;
            List<SelectListItem> locations = null;
            try
            {
                con = new SqlConnection(connString);
                SqlCommand cmd = new SqlCommand("SP_Location", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Parent", parent);
                
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                locations = new List<SelectListItem>();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    SelectListItem item = new SelectListItem();
                    item.Value = ds.Tables[0].Rows[i]["Id"].ToString();
                    item.Text = ds.Tables[0].Rows[i]["Name"].ToString();
                    

                    locations.Add(item);
                }
                return locations;
            }
            catch (Exception ex)
            {
                return locations;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
