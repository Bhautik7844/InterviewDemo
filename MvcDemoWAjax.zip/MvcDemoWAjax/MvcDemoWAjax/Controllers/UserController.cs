﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MvcDemoWAjax.Models;
using MvcDemoWAjax.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcDemoWAjax.Controllers
{
    public class UserController : Controller
    {
        private readonly IConfiguration configuration;
        public UserController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }

        // GET: UserController
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetUsers(int id = 0)
        {
            UserService userService = new UserService(configuration);

            var users = userService.GetUsers(id);

            return Json(users);
        }

        [HttpGet]
        public JsonResult GetLocations(int parent = 1)
        {
            UserService userService = new UserService(configuration);

            var locations = userService.GetLocations(parent);

            return Json(locations);
        }

        [HttpPost]
        public ActionResult CreateOrEdit(User user)
        {
            UserService userService = new UserService(configuration);

            string result = userService.InsertOrUpdateUser(user);

            return Content(result);
        }
   
        [HttpGet]
        public ActionResult Delete(int id)
        {
            UserService userService = new UserService(configuration);

            int result = userService.DeleteUser(id);

            return Content(result.ToString());
        }
    }
}
